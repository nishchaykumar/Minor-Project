<script type="text/javascript">
$(document).ready(function(){
setinterval(function()
{
$.ajax
({
type:'post',
url:'',
data:{
get_online_visiter:"online_visitor",
}
success:function(responce) {
if(responce!="")
{
$("#online_visior_val").html(response);
}
}
});
},10000)
